package com.freenet.vpn

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.provider.Settings
import android.util.Base64
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray

/** خدمة VPN تشغّل نواة Xray وتمرّر لها واجهة TUN مباشرة. */
class XrayVpnService : VpnService() {
    private var pfd: ParcelFileDescriptor? = null
    private var core: CoreController? = null
    private var tag = "proxy"

    private val cb = object : CoreCallbackHandler {
        override fun startup(): Long = 0
        override fun shutdown(): Long = 0
        override fun onEmitStatus(l: Long, s: String?): Long = 0
    }

    override fun onCreate() { super.onCreate(); instance = this }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY
    override fun onRevoke() { stopCore(); stopSelf() }
    override fun onDestroy() { stopCore(); if (instance === this) instance = null; super.onDestroy() }

    @Synchronized
    fun start(json: String) {
        stopCore()
        val b = Builder().setSession("Free Net VPN").setMtu(1500)
            .addAddress("10.10.10.2", 30).addAddress("fd00:10:10::2", 126)
            .addRoute("0.0.0.0", 0).addRoute("::", 0)
            .addDnsServer("1.1.1.1").addDnsServer("8.8.8.8")
        // التطبيق نفسه (حيث تعمل نواة Xray) خارج النفق حتى لا تتكوّن حلقة
        try { b.addDisallowedApplication(packageName) } catch (_: Exception) {}
        val p = b.establish() ?: throw IllegalStateException("لم يتم منح إذن VPN")
        pfd = p
        try {
            go.Seq.setContext(applicationContext)
            val id = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: "freenet"
            val key = Base64.encodeToString(id.toByteArray().copyOf(32), Base64.NO_PADDING or Base64.URL_SAFE or Base64.NO_WRAP)
            Libv2ray.initCoreEnv(filesDir.absolutePath, key)
            val c = Libv2ray.newCoreController(cb)
            tag = XrayCfg.proxyTag(json)
            c.startLoop(json, p.fd)
            core = c
            Vpn.up.value = true
        } catch (e: Throwable) {
            stopCore()
            throw e
        }
    }

    @Synchronized
    fun stopCore() {
        try { core?.stopLoop() } catch (_: Throwable) {}
        core = null
        try { pfd?.close() } catch (_: Throwable) {}
        pfd = null
        Vpn.up.value = false
    }

    /** يرجع (تنزيل، رفع) منذ آخر استدعاء؛ الاستعلام يصفّر العدّادات. الصيغة: tag,direction,value;... */
    fun queryDelta(): Pair<Long, Long> = try {
        var down = 0L
        var up = 0L
        (core?.queryAllOutboundTrafficStats() ?: "").split(';').forEach { e ->
            val f = e.split(',')
            if (f.size == 3 && f[0].trim() == tag) {
                val v = f[2].trim().toLongOrNull() ?: 0L
                if (f[1].trim() == "downlink") down += v else if (f[1].trim() == "uplink") up += v
            }
        }
        down to up
    } catch (_: Throwable) { 0L to 0L }

    companion object { @Volatile var instance: XrayVpnService? = null }
}
