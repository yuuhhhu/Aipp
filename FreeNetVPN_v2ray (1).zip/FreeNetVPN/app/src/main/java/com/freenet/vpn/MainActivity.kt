package com.freenet.vpn

import android.app.Activity
import android.app.Application
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.android.gms.ads.*
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

val Blue = Color(0xFF2196F3); val Green = Color(0xFF00E676); val Bg = Color(0xFF0B1220); val Card = Color(0xFF141E33)

class VM(app: Application) : AndroidViewModel(app) {
    val repo = Repo(app)
    var servers by mutableStateOf(repo.servers()); var favs by mutableStateOf(repo.favs)
    var pings by mutableStateOf(mapOf<String, Int>()); var selected by mutableStateOf<Server?>(servers.firstOrNull())
    var connected by mutableStateOf(false); var busy by mutableStateOf(false)
    var seconds by mutableIntStateOf(0); var elapsed by mutableIntStateOf(0)
    var rx by mutableLongStateOf(0); var tx by mutableLongStateOf(0)
    var down by mutableLongStateOf(0); var upS by mutableLongStateOf(0)
    var msg by mutableStateOf("")
    private var rewarded: RewardedAd? = null

    init { Vpn.init(app); repo.dailyGrant(); seconds = repo.seconds; refresh(); loadAd()
        viewModelScope.launch { while (true) { delay(1000); tick() } } }

    private suspend fun tick() {
        connected = Vpn.up.value
        if (!connected) { down = 0; upS = 0; return }
        elapsed++; repo.seconds = repo.seconds - 1; seconds = repo.seconds
        val (r, t) = Vpn.stats(); down = r - rx; upS = t - tx; rx = r; tx = t
        if (seconds <= 0) { Vpn.disconnect(); msg = "انتهى الوقت — شاهد إعلاناً لإضافة وقت" }
    }
    fun reload() { servers = repo.servers(); favs = repo.favs; if (selected == null) selected = servers.firstOrNull() }
    fun refresh() = viewModelScope.launch { val ok = repo.refreshRemote(); msg = if (ok) "تم تحديث السيرفرات" else "تعذّر التحديث من GitHub"; reload(); servers.forEach { s ->
        launch { pings = pings + (s.id to ping(s)) } } }
    fun toggle(prepared: Boolean) = viewModelScope.launch {
        if (Vpn.up.value) { Vpn.disconnect(); elapsed = 0; rx = 0; tx = 0; return@launch }
        val s = selected ?: run { msg = "اختر سيرفراً أو استورد ملفاً"; return@launch }
        if (seconds <= 0) { msg = "لا يوجد وقت متبقٍ — شاهد إعلاناً"; return@launch }
        busy = true
        try { Vpn.connect(s); msg = "" } catch (e: Exception) { msg = "فشل الاتصال: ${e.message}" }
        busy = false
    }
    fun fav(s: Server) { repo.favs = if (s.id in favs) favs - s.id else favs + s.id; reload() }
    fun import(name: String, text: String) {
        val t = text.trim().removePrefix("\uFEFF")
        try {
            when {
                t.startsWith("[") || t.startsWith("{") -> {
                    val n = repo.addFromJson(t, name); reload(); msg = "تم استيراد $n سيرفر"
                }
                XrayCfg.isLink(t.lineSequence().first()) -> {
                    val n = repo.addFromLinks(t); reload(); msg = "تم استيراد $n سيرفر"
                }
                else -> {
                    com.wireguard.config.Config.parse(t.byteInputStream())
                    val h = Regex("Endpoint\\s*=\\s*([^:\\s]+):(\\d+)").find(t)
                    repo.add(Server("l:$name", name, "ملف مستورد", h?.groupValues?.get(1) ?: "", h?.groupValues?.get(2)?.toInt() ?: 51820, t))
                    reload(); msg = "تم استيراد $name"
                }
            }
        } catch (e: Exception) { msg = "ملف غير صالح: ${e.message}" }
    }
    fun delete(s: Server) { repo.remove(s.id); if (selected?.id == s.id) selected = null; reload() }
    fun loadAd() = RewardedAd.load(getApplication(), "ca-app-pub-3940256099942544/5224354917",
        AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdLoaded(a: RewardedAd) { rewarded = a }
            override fun onAdFailedToLoad(e: LoadAdError) { rewarded = null } })
    fun showAd(act: Activity) { val a = rewarded ?: run { msg = "الإعلان غير جاهز بعد"; loadAd(); return }
        a.show(act) { repo.seconds += REWARD_SECONDS; seconds = repo.seconds; msg = "+30 دقيقة" }
        rewarded = null; loadAd() }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b); MobileAds.initialize(this)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Bg, surface = Card)) { Screen() } } }
}

fun fmt(s: Int) = "%02d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
fun mb(b: Long) = if (b > 1 shl 20) "%.1f MB".format(b / 1048576.0) else "${b / 1024} KB"

@Composable fun Screen(vm: VM = viewModel()) {
    val act = androidx.compose.ui.platform.LocalContext.current as Activity
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) vm.toggle(true) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> u?.let {
        vm.import(it.lastPathSegment?.substringAfterLast('/')?.removeSuffix(".conf")?.removeSuffix(".json") ?: "config",
            act.contentResolver.openInputStream(it)!!.bufferedReader().readText()) } }
    val on = vm.connected
    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp).systemBarsPadding()) {
        Text("Free Net VPN", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("الإنترنت المجاني", color = Green, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
        Box(Modifier.align(Alignment.CenterHorizontally).size(150.dp).clip(CircleShape)
            .background(Brush.linearGradient(if (on) listOf(Green, Blue) else listOf(Color(0xFF37474F), Color(0xFF263238))))
            .clickable(enabled = !vm.busy) {
                if (on) vm.toggle(true) else VpnService.prepare(act)?.let { perm.launch(it) } ?: vm.toggle(true) },
            contentAlignment = Alignment.Center) {
            if (vm.busy) CircularProgressIndicator(color = Color.White) else
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.PowerSettingsNew, null, tint = Color.White, modifier = Modifier.size(44.dp))
                    Text(if (on) "DISCONNECT" else "CONNECT", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp) } }
        Text(if (on) "متصل" else "غير متصل", color = if (on) Green else Color.Gray,
            modifier = Modifier.align(Alignment.CenterHorizontally).padding(8.dp))
        if (vm.msg.isNotEmpty()) Text(vm.msg, color = Color(0xFFFFB74D), fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card).padding(12.dp), Arrangement.SpaceAround) {
            Stat("المدة", fmt(vm.elapsed)); Stat("↓", mb(vm.down) + "/s"); Stat("↑", mb(vm.upS) + "/s"); Stat("البيانات", mb(vm.rx + vm.tx)) }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text("الوقت المتبقي: ${fmt(vm.seconds)}", color = Color.White)
            Button(onClick = { vm.showAd(act) }) { Text("▶ +30 د") } }
        Row(Modifier.padding(vertical = 4.dp)) {
            TextButton({ pick.launch(arrayOf("*/*")) }) { Icon(Icons.Default.Add, null); Text(" استيراد .conf / .json / رابط") }
            TextButton({ vm.refresh() }) { Icon(Icons.Default.Refresh, null); Text(" تحديث/Ping") } }
        LazyColumn(Modifier.weight(1f)) {
            items(vm.servers.sortedByDescending { it.id in vm.favs }) { s ->
                val p = vm.pings[s.id]
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(12.dp))
                    .background(if (vm.selected?.id == s.id) Blue.copy(.25f) else Card)
                    .clickable { vm.selected = s }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(s.name, color = Color.White); Text(s.country, color = Color.Gray, fontSize = 12.sp) }
                    Text(when { p == null -> "…"; p < 0 -> "✕"; else -> "$p ms" }, color = if (p != null && p in 0..150) Green else Color(0xFFFFB74D))
                    IconButton({ vm.fav(s) }) { Icon(if (s.id in vm.favs) Icons.Default.Star else Icons.Default.StarBorder, null, tint = Color(0xFFFFD54F)) }
                    if (!s.remote) IconButton({ vm.delete(s) }) { Icon(Icons.Default.Delete, null, tint = Color.Gray) } } } }
        AndroidView(
            modifier = Modifier.fillMaxWidth(),
            factory = { c -> AdView(c).apply {
                setAdSize(AdSize.BANNER)
                adUnitId = "ca-app-pub-3940256099942544/6300978111"
                loadAd(AdRequest.Builder().build())
            } }
        )
    }
}
@Composable fun Stat(t: String, v: String) = Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text(t, color = Color.Gray, fontSize = 11.sp); Text(v, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
