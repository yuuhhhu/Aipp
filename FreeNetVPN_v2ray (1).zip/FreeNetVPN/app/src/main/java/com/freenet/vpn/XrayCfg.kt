package com.freenet.vpn

import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetAddress

/** يحوّل رابط vless:// أو trojan:// أو vmess:// (أو ملف Xray JSON كامل) إلى إعدادات Xray مع مدخل TUN. */
object XrayCfg {
    private val SCHEMES = listOf("vless://", "trojan://", "vmess://")

    fun isLink(s: String) = s.trim().let { t -> SCHEMES.any { t.startsWith(it, ignoreCase = true) } }
    fun isJson(s: String) = s.trim().startsWith("{") && s.contains("\"outbounds\"")
    fun isXray(s: String) = isLink(s) || isJson(s)

    private class P(val host: String, val port: Int, val name: String, val make: (String) -> JSONObject)

    private fun dec(s: String): String = Uri.decode(s)

    private fun query(q: String): Map<String, String> =
        q.split('&').filter { it.contains('=') }
            .associate { dec(it.substringBefore('=')) to dec(it.substringAfter('=')) }

    private fun hostPort(hp0: String): Pair<String, Int> {
        val hp = hp0.trimEnd('/')
        return when {
            hp.startsWith("[") -> hp.substring(1, hp.indexOf(']')) to (hp.substringAfter("]:", "443").toIntOrNull() ?: 443)
            ':' in hp -> hp.substringBeforeLast(':') to (hp.substringAfterLast(':').toIntOrNull() ?: 443)
            else -> hp to 443
        }
    }

    private fun b64(s: String): String {
        var x = s.trim().replace('-', '+').replace('_', '/')
        while (x.length % 4 != 0) x += "="
        return String(Base64.decode(x, Base64.DEFAULT), Charsets.UTF_8)
    }

    private fun stream(q: Map<String, String>, host: String, defSec: String): JSONObject {
        val net = (q["type"] ?: "tcp").let { if (it == "splithttp") "xhttp" else it }
        val sec = q["security"]?.takeIf { it.isNotEmpty() } ?: defSec
        val hostHdr = q["host"]?.takeIf { it.isNotEmpty() }
        val path = q["path"]?.takeIf { it.isNotEmpty() } ?: "/"
        val o = JSONObject().put("network", net).put("security", sec)
        when (net) {
            "ws" -> o.put("wsSettings", JSONObject().put("path", path)
                .put("headers", JSONObject().apply { hostHdr?.let { put("Host", it) } }))
            "grpc" -> o.put("grpcSettings", JSONObject()
                .put("serviceName", q["serviceName"]?.takeIf { it.isNotEmpty() } ?: path.trim('/'))
                .put("multiMode", q["mode"] == "multi"))
            "httpupgrade" -> o.put("httpupgradeSettings", JSONObject().put("path", path)
                .apply { hostHdr?.let { put("host", it) } })
            "xhttp" -> o.put("xhttpSettings", JSONObject().put("path", path).put("mode", q["mode"] ?: "auto")
                .apply { hostHdr?.let { put("host", it) } })
            "tcp" -> if (q["headerType"] == "http") o.put("tcpSettings", JSONObject().put("header", JSONObject()
                .put("type", "http").put("request", JSONObject()
                    .put("path", JSONArray().put(path))
                    .put("headers", JSONObject().put("Host", JSONArray().put(hostHdr ?: host))))))
        }
        val sni = q["sni"]?.takeIf { it.isNotEmpty() } ?: hostHdr ?: host
        val fp = q["fp"]?.takeIf { it.isNotEmpty() } ?: "chrome"
        when (sec) {
            "tls" -> o.put("tlsSettings", JSONObject().put("serverName", sni).put("fingerprint", fp)
                .apply { q["alpn"]?.takeIf { it.isNotEmpty() }?.let { put("alpn", JSONArray(it.split(','))) } })
            "reality" -> o.put("realitySettings", JSONObject().put("serverName", sni).put("fingerprint", fp)
                .put("publicKey", q["pbk"] ?: "").put("shortId", q["sid"] ?: "").put("spiderX", q["spx"] ?: ""))
        }
        return o
    }

    private fun parseVmess(s: String): P {
        val j = JSONObject(b64(s.substringAfter("://").substringBefore('#')))
        val host = j.getString("add")
        val port = j.optString("port").toInt()
        val q = mapOf(
            "type" to j.optString("net", "tcp"),
            "security" to (if (j.optString("tls") == "tls") "tls" else "none"),
            "host" to j.optString("host"), "path" to j.optString("path"),
            "serviceName" to j.optString("path"), "sni" to j.optString("sni"),
            "fp" to j.optString("fp"), "alpn" to j.optString("alpn"),
            "headerType" to j.optString("type"))
        return P(host, port, j.optString("ps")) { addr ->
            val user = JSONObject().put("id", j.getString("id"))
                .put("alterId", j.optString("aid", "0").toIntOrNull() ?: 0)
                .put("security", j.optString("scy").ifEmpty { "auto" })
            val server = JSONObject().put("address", addr).put("port", port).put("users", JSONArray().put(user))
            JSONObject().put("tag", "proxy").put("protocol", "vmess")
                .put("settings", JSONObject().put("vnext", JSONArray().put(server)))
                .put("streamSettings", stream(q, host, "none"))
        }
    }

    private fun parse(raw: String): P {
        val s = raw.trim()
        val scheme = s.substringBefore("://").lowercase()
        if (scheme == "vmess") return parseVmess(s)
        var rest = s.substringAfter("://")
        val name = if ('#' in rest) dec(rest.substringAfter('#')) else ""
        rest = rest.substringBefore('#')
        val q = if ('?' in rest) query(rest.substringAfter('?')) else emptyMap()
        rest = rest.substringBefore('?')
        require('@' in rest) { "رابط غير صالح: لا يوجد @" }
        val user = dec(rest.substringBeforeLast('@'))
        val (host, port) = hostPort(rest.substringAfterLast('@'))
        return P(host, port, name) { addr ->
            val settings = if (scheme == "vless") {
                val u = JSONObject().put("id", user).put("encryption", q["encryption"]?.takeIf { it.isNotEmpty() } ?: "none")
                q["flow"]?.takeIf { it.isNotEmpty() }?.let { u.put("flow", it) }
                val server = JSONObject().put("address", addr).put("port", port).put("users", JSONArray().put(u))
                JSONObject().put("vnext", JSONArray().put(server))
            } else {
                val server = JSONObject().put("address", addr).put("port", port).put("password", user)
                JSONObject().put("servers", JSONArray().put(server))
            }
            JSONObject().put("tag", "proxy").put("protocol", scheme).put("settings", settings)
                .put("streamSettings", stream(q, host, if (scheme == "trojan") "tls" else "none"))
        }
    }

    private fun jsonEndpoint(root: JSONObject): Pair<String, Int>? {
        val arr = root.optJSONArray("outbounds") ?: return null
        for (i in 0 until arr.length()) {
            val st = arr.getJSONObject(i).optJSONObject("settings") ?: continue
            val v = st.optJSONArray("vnext")?.optJSONObject(0) ?: st.optJSONArray("servers")?.optJSONObject(0) ?: st
            val a = v.optString("address")
            if (a.isNotEmpty()) return a to v.optInt("port", 443)
        }
        return null
    }

    /** عنوان السيرفر ومنفذه (لعرض الـ Ping) */
    fun endpoint(raw: String): Pair<String, Int>? = try {
        if (isLink(raw)) parse(raw).let { it.host to it.port } else jsonEndpoint(JSONObject(raw))
    } catch (e: Exception) { null }

    /** الاسم الموجود بعد # في الرابط */
    fun nameOf(raw: String): String = try { if (isLink(raw)) parse(raw).name else "" } catch (e: Exception) { "" }

    private fun resolve(h: String): String = try {
        if (':' in h || h.all { it.isDigit() || it == '.' }) h
        else InetAddress.getAllByName(h).firstOrNull { it.address.size == 4 }?.hostAddress ?: h
    } catch (e: Exception) { h }

    /** وسم المخرج الذي تُحسب عليه الإحصائيات */
    fun proxyTag(json: String): String = try {
        JSONObject(json).getJSONArray("outbounds").getJSONObject(0).optString("tag").ifEmpty { "proxy" }
    } catch (e: Exception) { "proxy" }

    /**
     * يبني إعدادات Xray النهائية مع مدخل TUN.
     * resolveDns=true يحوّل اسم السيرفر إلى IP قبل رفع النفق لتفادي حلقة DNS.
     */
    fun build(raw: String, resolveDns: Boolean = true): String {
        val root: JSONObject
        if (isLink(raw)) {
            val p = parse(raw)
            val addr = if (resolveDns) resolve(p.host) else p.host
            root = JSONObject().put("log", JSONObject().put("loglevel", "warning"))
                .put("outbounds", JSONArray().put(p.make(addr))
                    .put(JSONObject().put("tag", "direct").put("protocol", "freedom"))
                    .put(JSONObject().put("tag", "block").put("protocol", "blackhole")))
                .put("routing", JSONObject().put("domainStrategy", "AsIs").put("rules", JSONArray()))
        } else {
            root = JSONObject(raw)
        }
        val tun = JSONObject().put("tag", "tun-in").put("port", 0).put("protocol", "tun")
            .put("settings", JSONObject().put("name", "xray0").put("mtu", 1500))
        root.put("inbounds", JSONArray().put(tun))
        if (!root.has("stats")) root.put("stats", JSONObject())
        if (!root.has("policy")) root.put("policy", JSONObject().put("system", JSONObject()
            .put("statsOutboundUplink", true).put("statsOutboundDownlink", true)))
        return root.toString()
    }
}
