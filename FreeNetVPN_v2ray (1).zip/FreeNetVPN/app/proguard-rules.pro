-keep class com.wireguard.** { *; }

-keep class go.** { *; }
-keep class libv2ray.** { *; }
