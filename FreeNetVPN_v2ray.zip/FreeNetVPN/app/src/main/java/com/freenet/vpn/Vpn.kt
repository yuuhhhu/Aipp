package com.freenet.vpn

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout

/**
 * محرك الاتصال: WireGuard (GoBackend) أو Xray (VLESS / Trojan / VMess) حسب نوع إعدادات السيرفر.
 */
object Vpn {
    private lateinit var backend: GoBackend
    private lateinit var app: Context
    val up = MutableStateFlow(false)
    private var xray = false
    private var wg: Server? = null
    private var xrx = 0L
    private var xtx = 0L

    private val tunnel = object : Tunnel {
        override fun getName() = "freenet"
        override fun onStateChange(s: Tunnel.State) { if (!xray) up.value = s == Tunnel.State.UP }
    }
    var last: Server? = null
    var wanted = false

    fun init(c: Context) {
        if (::backend.isInitialized) return
        app = c.applicationContext
        backend = GoBackend(app)
        val cm = c.getSystemService(ConnectivityManager::class.java)
        // إعادة الاتصال تلقائياً عند عودة الشبكة (WireGuard فقط؛ Xray يعيد الاتصال بنفسه)
        cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(n: Network) {
                val s = last
                if (wanted && s != null && !xray) try { apply(s, true) } catch (_: Exception) {}
            }
        })
    }

    private fun apply(s: Server, on: Boolean) {
        val cfg = Config.parse(s.config.byteInputStream())
        backend.setState(tunnel, if (on) Tunnel.State.UP else Tunnel.State.DOWN, cfg)
    }

    private fun wgStop() {
        wg?.let { try { apply(it, false) } catch (_: Exception) {} }
        wg = null
    }

    suspend fun connect(s: Server) = withContext(Dispatchers.IO) {
        last = s; wanted = true
        if (XrayCfg.isXray(s.config)) {
            wgStop()
            xray = true; xrx = 0L; xtx = 0L
            val json = XrayCfg.build(s.config)
            val svc = XrayVpnService.instance ?: run {
                app.startService(Intent(app, XrayVpnService::class.java))
                withTimeout(5000) {
                    while (XrayVpnService.instance == null) delay(50)
                    XrayVpnService.instance!!
                }
            }
            svc.start(json)
        } else {
            xray = false
            XrayVpnService.instance?.stopCore()
            wg = s
            apply(s, true)
        }
    }

    suspend fun disconnect() = withContext(Dispatchers.IO) {
        wanted = false
        if (xray) XrayVpnService.instance?.stopCore() else wgStop()
    }

    fun stats(): Pair<Long, Long> =
        if (xray) {
            XrayVpnService.instance?.let { xrx += it.query("downlink"); xtx += it.query("uplink") }
            xrx to xtx
        } else try {
            backend.getStatistics(tunnel).let { it.totalRx() to it.totalTx() }
        } catch (_: Exception) { 0L to 0L }
}
