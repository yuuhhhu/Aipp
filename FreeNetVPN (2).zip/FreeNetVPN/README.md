# Free Net VPN
1. افتح المجلد في Android Studio (Ladybug+) ← Sync ← Build > Build APK.
2. في Data.kt غيّر SERVERS_URL. صيغة servers.json:
   [{"id":"de1","name":"Frankfurt","country":"Germany","host":"1.2.3.4","port":443,"config":"[Interface]\nPrivateKey=...\nAddress=10.0.0.2/32\nDNS=1.1.1.1\n[Peer]\nPublicKey=...\nEndpoint=1.2.3.4:51820\nAllowedIPs=0.0.0.0/0"}]
3. استبدل معرّفات AdMob التجريبية (Manifest + MainActivity) قبل النشر.
