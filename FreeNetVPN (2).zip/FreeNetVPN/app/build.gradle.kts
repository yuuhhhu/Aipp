plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.freenet.vpn"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.freenet.vpn"
        minSdk = 26          // Android 8
        targetSdk = 35       // ارفعه إلى 36 (Android 16) عند تحديث AGP
        versionCode = 1; versionName = "1.0"
    }
    buildTypes { release { isMinifyEnabled = true
        proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("com.wireguard.android:tunnel:1.0.20230706")   // محرك WireGuard الرسمي
    implementation("com.google.android.gms:play-services-ads:23.5.0")
}
