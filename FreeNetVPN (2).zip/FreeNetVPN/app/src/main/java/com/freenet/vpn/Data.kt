package com.freenet.vpn

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.time.LocalDate

data class Server(val id: String, val name: String, val country: String,
                  val host: String, val port: Int, val config: String, val remote: Boolean = false)

/** رابط قائمة السيرفرات (JSON) التي تديرها أنت. غيّره لرابط لوحة التحكم الخاصة بك. */
const val SERVERS_URL = "https://raw.githubusercontent.com/yuuhhhu/Aipp/main/servers.json"
const val DAILY_FREE_SECONDS = 30 * 60
const val REWARD_SECONDS = 30 * 60

class Repo(c: Context) {
    private val p = c.getSharedPreferences("fn", Context.MODE_PRIVATE)

    fun servers(): List<Server> {
        val a = JSONArray(p.getString("servers", "[]"))
        return (0 until a.length()).map { val o = a.getJSONObject(it)
            Server(o.getString("id"), o.getString("name"), o.optString("country"), o.optString("host"),
                o.optInt("port", 443), o.getString("config"), o.optBoolean("remote")) }
    }
    private fun save(l: List<Server>) = p.edit().putString("servers", JSONArray(l.map {
        JSONObject().put("id", it.id).put("name", it.name).put("country", it.country).put("host", it.host)
            .put("port", it.port).put("config", it.config).put("remote", it.remote) }).toString()).apply()

    fun add(s: Server) = save(servers().filter { it.id != s.id } + s)

    /** يحوّل نص JSON إلى قائمة سيرفرات: [..] أو {..} أو {"servers":[..]} */
    private fun parseServers(text: String, prefix: String, remote: Boolean): List<Server> {
        val t = text.trim().removePrefix("\uFEFF")
        val arr: JSONArray = if (t.startsWith("[")) JSONArray(t) else {
            val o = JSONObject(t); o.optJSONArray("servers") ?: JSONArray().put(o) }
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val cfg = o.getString("config")
            com.wireguard.config.Config.parse(cfg.byteInputStream())   // يتحقق من صحة الإعدادات
            val m = Regex("Endpoint\\s*=\\s*([^:\\s]+):(\\d+)").find(cfg)
            val name = o.optString("name").ifEmpty { "Server ${i + 1}" }
            Server(prefix + o.optString("id").ifEmpty { name }, name, o.optString("country", "مستورد"),
                o.optString("host").ifEmpty { m?.groupValues?.get(1) ?: "" },
                if (o.has("port")) o.getInt("port") else (m?.groupValues?.get(2)?.toInt() ?: 51820),
                cfg, remote)
        }
    }

    /** يستورد سيرفرات من ملف JSON محلي ويرجع عددها */
    fun addFromJson(text: String): Int {
        val list = parseServers(text, "l:", false)
        save(servers().filter { o -> list.none { it.id == o.id } } + list)
        return list.size
    }

    fun remove(id: String) = save(servers().filter { it.id != id })

    var favs: Set<String>
        get() = p.getStringSet("favs", emptySet())!!
        set(v) = p.edit().putStringSet("favs", v).apply()

    var seconds: Int
        get() = p.getInt("sec", 0)
        set(v) = p.edit().putInt("sec", v.coerceAtLeast(0)).apply()

    /** باقة مجانية يومية */
    fun dailyGrant() {
        val today = LocalDate.now().toString()
        if (p.getString("day", "") != today) {
            p.edit().putString("day", today).apply(); seconds = maxOf(seconds, DAILY_FREE_SECONDS)
        }
    }

    /** يجلب قائمة السيرفرات من SERVERS_URL (HTTPS) ويستبدل السيرفرات البعيدة القديمة */
    suspend fun refreshRemote(): Boolean = withContext(Dispatchers.IO) {
        try {
            val c = URL(SERVERS_URL).openConnection() as HttpURLConnection
            c.connectTimeout = 8000; c.readTimeout = 8000
            c.useCaches = false; c.setRequestProperty("Cache-Control", "no-cache")
            val text = c.inputStream.bufferedReader().readText()
            val remote = parseServers(text, "r:", true)
            save(servers().filter { !it.remote } + remote); true
        } catch (e: Exception) { false }
    }
}

/** قياس Ping عبر اتصال TCP (ms) أو -1 عند الفشل */
suspend fun ping(s: Server): Int = withContext(Dispatchers.IO) {
    try { val t = System.nanoTime()
        Socket().use { it.connect(InetSocketAddress(s.host, s.port), 3000) }
        ((System.nanoTime() - t) / 1_000_000).toInt()
    } catch (e: Exception) { -1 }
}
