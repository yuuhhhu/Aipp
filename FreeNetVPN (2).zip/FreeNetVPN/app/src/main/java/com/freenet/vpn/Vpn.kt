package com.freenet.vpn

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext

/**
 * محرك الاتصال. WireGuard مُنفَّذ بالكامل (GoBackend + VpnService الرسمي).
 * لإضافة SSH/TLS/V2Ray نفّذ نفس الواجهة بنواة مناسبة (Xray/libv2ray) وسجّلها هنا.
 */
object Vpn {
    private lateinit var backend: GoBackend
    val up = MutableStateFlow(false)
    private val tunnel = object : Tunnel {
        override fun getName() = "freenet"
        override fun onStateChange(s: Tunnel.State) { up.value = s == Tunnel.State.UP }
    }
    var last: Server? = null
    var wanted = false

    fun init(c: Context) {
        if (::backend.isInitialized) return
        backend = GoBackend(c.applicationContext)
        val cm = c.getSystemService(ConnectivityManager::class.java)
        // إعادة الاتصال تلقائياً عند عودة الشبكة
        cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(n: Network) {
                val s = last
                if (wanted && s != null) try { apply(s, true) } catch (_: Exception) {}
            }
        })
    }
    private fun apply(s: Server, on: Boolean) {
        val cfg = Config.parse(s.config.byteInputStream())
        backend.setState(tunnel, if (on) Tunnel.State.UP else Tunnel.State.DOWN, cfg)
    }
    suspend fun connect(s: Server) = withContext(Dispatchers.IO) { last = s; wanted = true; apply(s, true) }
    suspend fun disconnect() = withContext(Dispatchers.IO) { wanted = false; last?.let { apply(it, false) } }
    fun stats(): Pair<Long, Long> = try {
        backend.getStatistics(tunnel).let { it.totalRx() to it.totalTx() } } catch (_: Exception) { 0L to 0L }
}
